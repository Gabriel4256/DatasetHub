The documentation is available online here:
https://demo.createx.studio/createx/docs/dev-setup.html
OR
Offline: inside CreateX/dist/docs folder